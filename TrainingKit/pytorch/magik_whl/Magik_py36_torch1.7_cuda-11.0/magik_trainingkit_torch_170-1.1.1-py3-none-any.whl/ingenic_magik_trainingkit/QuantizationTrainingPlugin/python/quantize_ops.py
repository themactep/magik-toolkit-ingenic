#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
  Note: Python cell C++ interface about quantize_weight or quantize_feature based on Pytorch
  Author: Magik Development Team
  Date: Dec 2019
"""
import math
import numpy as np
import json
import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.autograd import Function
from torch.onnx.symbolic_helper import parse_args

import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import ingenic_magik_trainingkit_quantization_training_plugin as imtk_qtp

OBJ_INDEX = 0
OBJ_ID = 0
global_step = torch.tensor(0)

def get_padding(x, kernel_size, stride, pad_value=0.):
    if not isinstance(stride, tuple):
        stride = (stride, stride)
    input_height = x.shape[2]
    input_width = x.shape[3]
    output_height = math.ceil((float)(input_height) / (float)(stride[0]))
    output_width = math.ceil((float)(input_width) / (float)(stride[1]))
    pad_needed_height = (output_height -
                         1) * stride[0] + kernel_size[0] - input_height
    pad_top = int(pad_needed_height // 2)
    pad_bottom = int(pad_needed_height - pad_top)
    pad_needed_width = (output_width -
                        1) * stride[1] + kernel_size[1] - input_width
    pad_left = int(pad_needed_width // 2)
    pad_right = int(pad_needed_width - pad_left)

    pad = nn.ConstantPad2d((pad_left, pad_right, pad_top, pad_bottom),
                           pad_value)
    y = pad(x)
    return y

def get_obj_name(obj):
    global OBJ_INDEX
    global OBJ_ID
    if OBJ_INDEX == 0:
        OBJ_ID = id(obj)
        OBJ_INDEX += 1
        return "layer_%d" % (OBJ_INDEX)
    elif OBJ_ID != id(obj):
        OBJ_INDEX += 1
        return "layer_%d" % (OBJ_INDEX)
    else:
        OBJ_INDEX = 1
        return "layer_%d" % (OBJ_INDEX)

class upsample(torch.autograd.Function):
    @staticmethod
    @parse_args('v', 'v', 'f', 's')
    def symbolic(g, input, scales, scale_alpha, mode):
        args = [input, scales]
        kwargs = {
            "mode_s": mode
        }
        return g.op("Upsample",
                    *args,
                    **kwargs)

    @staticmethod
    def forward(ctx, input, scales, scale_alpha, mode):
        ctx.shape = input.shape
        kernel_h, kernel_w = int(scales[2].item()), int(scales[3].item())
        ctx.scale_factor = (kernel_h, kernel_w)

        n, c, h, w = input.shape
        output = torch.ones([n, c, kernel_h * h, kernel_w * w],
                            dtype=torch.float32, device=input.device) * scale_alpha

        for i in range(w):
            for j in range(h):
                 output[:, :, j * kernel_h, i * kernel_w] = input[:, :, j, i]

        return output

    def backward(ctx, grad_output):
        n, c, h, w = ctx.shape
        kernel_h, kernel_w = ctx.scale_factor
        grad_input = torch.ones([n, c, h, w],
                                dtype=torch.float32, device=grad_output.device)
        for i in range(w):
            for j in range(h):
                grad_input[:, :, j, i] = grad_output[:, :, j * kernel_h, i * kernel_w]

        return grad_input, None, None, None

class n_op(torch.autograd.Function):
    @staticmethod
    @parse_args('v', 'i', 'i', 'i')
    def symbolic(g, input, op_target, op_attr, target_device):
        args = [input]
        return g.op("NOp",
                    *args,
                    op_target_s=op_target,
                    op_attr_s=op_attr,
                    version_i=int(1001),
                    target_device_s=target_device)

    @staticmethod
    def forward(ctx, input, op_target, op_attr, target_device):
        output = imtk_qtp.n_op(input, op_target, op_attr, target_device)
        return output

    @staticmethod
    def backward(ctx, grad_output):
        grad_in = grad_output
        return grad_in, None, None, None


class quantize_weight(torch.autograd.Function):
    @staticmethod
    @parse_args('v', 'v', 'i', 'i', 'i', 'f', 'is', 's', 's')
    def symbolic(g, input, pre_max, weight_bitwidth, input_bitwidth,
                 output_bitwidth, factor, need_scale_weight, target_device,
                 name):
        args = [input, pre_max]
        kwargs = {
            "weight_bitwidth_i": weight_bitwidth,
            "input_bitwidth_i": input_bitwidth,
            "output_bitwidth_i": output_bitwidth,
            "factor_f": factor,
            "data_format_s": 'NCHW',
            "is_quantize_per_channel_i": True,
            "need_scale_weight_i": need_scale_weight,
            "target_device_s": target_device,
            "tensor_name_s": name
        }
        return g.op("QuantizeWeight", *args, **kwargs)

    @staticmethod
    def forward(ctx, input, pre_max, weight_bitwidth, input_bitwidth,
                output_bitwidth, factor, need_scale_weight, target_device,
                name):
        ctx.save_for_backward(input)
        output, pre_max = imtk_qtp.quantize_weight(input, pre_max,
                                                   weight_bitwidth, factor,
                                                   True, need_scale_weight,
                                                   target_device, 0.05, name)
        return output

    @staticmethod
    def backward(ctx, grad_output):
        grad_input = grad_output.clone()
        return grad_input, None, None, None, None, None, None, None, None


class quantize_feature(torch.autograd.Function):
    @staticmethod
    @parse_args('v', 'i', 'f', 'f', 's', 'is', 's', 's', 'i', 'i', 'f', 'f', 'is', 'is', 'f',
                'is', 'is', 'is', 'i')
    def symbolic(g,
                 input,
                 output_bitwidth,
                 clip_min_value=0.0,
                 clip_max_value=6.0,
                 target_device="Txx",
                 pre_lstm_layer=False,
                 data_format="NCHW",
                 name="",
                 input_bitwidth=32,
                 weight_bitwidth=32,
                 feature_var=255.0,
                 epsilon=1e-3,
                 is_fixpoint=False,
                 first_layer=False,
                 clip_min_value_pre=0.0,
                 with_negtive_alpha=False,
                 is_shortcut=False,
                 sc_input_same_clip=True,
                 op_in_channels=0):
        args = [input]
        kwargs = {
            "weight_bitwidth_i": weight_bitwidth,
            "input_bitwidth_i": input_bitwidth,
            "output_bitwidth_i": output_bitwidth,
            "clip_min_value_f": clip_min_value,
            "clip_max_value_f": clip_max_value,
            "img_var_f": feature_var,
            "clip_min_pre_f": clip_min_value_pre,
            "epsilon_f": epsilon,
            "target_device_s": target_device,
            "data_format_s": data_format,
            "is_fixpoint_i": is_fixpoint,
            "is_shortcut_i": is_shortcut,
            "sc_input_same_clip_i": sc_input_same_clip,
            "pre_lstm_layer_i": pre_lstm_layer,
            "first_layer_i": first_layer,
            "op_in_channels_i": op_in_channels,
            "version_i": int(1001),
            "tensor_name_s": name
        }
        return g.op("QuantizeFeature", *args, **kwargs)

    @staticmethod
    def forward(ctx,
                input,
                output_bitwidth,
                clip_min_value=0.0,
                clip_max_value=6.0,
                target_device="Txx",
                pre_lstm_layer=False,
                data_format="NCHW",
                name="",
                input_bitwidth=32,
                weight_bitwidth=32,
                feature_var=255.0,
                epsilon=1e-3,
                is_fixpoint=False,
                first_layer=False,
                clip_min_value_pre=0.0,
                with_negtive_alpha=False,
                is_shortcut=False,
                sc_input_same_clip=True,
                op_in_channels=0):

        ctx.save_for_backward(input)
        output = imtk_qtp.quantize_feature(
            [input], output_bitwidth, input_bitwidth, weight_bitwidth,
            float(clip_min_value), float(clip_max_value), target_device,
            float(feature_var), float(epsilon), is_fixpoint, first_layer,
            float(clip_min_value_pre), with_negtive_alpha, is_shortcut,
            sc_input_same_clip, pre_lstm_layer, op_in_channels, data_format, name)

        ctx.output_bitwidth = output_bitwidth
        ctx.clip_min_value = clip_min_value
        ctx.clip_max_value = clip_max_value
        return output

    @staticmethod
    def backward(ctx, grad_output):
        input, = ctx.saved_tensors
        grad_input = imtk_qtp.quantize_feature_backward(
            [grad_output, input], float(ctx.clip_min_value),
            float(ctx.clip_max_value))
        return grad_input, None, None, None, None, None, None, None, None, None, None, None


class quantize_feature_helper(torch.autograd.Function):
    @staticmethod
    @parse_args('v', 'v', 'v', 'v', 'v', 'v', 'v', 'v', 'v', 'i', 'f', 'f',
                's', 'i', 'i', 'f', 'f', 'is', 'is', 'f', 'is', 'is', 'is',
                'is', 'i', 's', 's')
    def symbolic(g,
                 input,
                 gamma,
                 beta,
                 mean,
                 var,
                 wscale,
                 bias,
                 negtive_alpha,
                 conv_res,
                 output_bitwidth,
                 clip_min_value=0.0,
                 clip_max_value=6.0,
                 target_device="Txx",
                 input_bitwidth=32,
                 weight_bitwidth=32,
                 feature_var=255.0,
                 epsilon=1e-3,
                 is_fixpoint=False,
                 first_layer=False,
                 clip_min_value_pre=0.0,
                 with_negtive_alpha=False,
                 is_shortcut=False,
                 sc_input_same_clip=True,
                 pre_lstm_layer=False,
                 op_in_channels=0,
                 data_format="NCHW",
                 name=""):
        args = [
            input, gamma, beta, mean, var, wscale, bias, negtive_alpha,
            conv_res
        ]
        kwargs = {
            "weight_bitwidth_i": weight_bitwidth,
            "input_bitwidth_i": input_bitwidth,
            "output_bitwidth_i": output_bitwidth,
            "clip_min_value_f": clip_min_value,
            "clip_max_value_f": clip_max_value,
            "img_var_f": feature_var,
            "clip_min_pre_f": clip_min_value_pre,
            "epsilon_f": epsilon,
            "target_device_s": target_device,
            "data_format_s": data_format,
            "is_fixpoint_i": is_fixpoint,
            "is_shortcut_i": is_shortcut,
            "sc_input_same_clip_i": sc_input_same_clip,
            "with_negtive_alpha_i": with_negtive_alpha,
            "pre_lstm_layer_i": pre_lstm_layer,
            "first_layer_i": first_layer,
            "op_in_channels_i": op_in_channels,
            "version_i": int(1001),
            "tensor_name_s": name,
        }
        return g.op("QuantizeFeature", *args, **kwargs)

    @staticmethod
    def forward(ctx,
                input,
                gamma,
                beta,
                mean,
                var,
                wscale,
                bias,
                negtive_alpha,
                conv_res,
                output_bitwidth,
                clip_min_value=0.0,
                clip_max_value=6.0,
                target_device="Txx",
                input_bitwidth=32,
                weight_bitwidth=32,
                feature_var=255.0,
                epsilon=1e-3,
                is_fixpoint=False,
                first_layer=False,
                clip_min_value_pre=0.0,
                with_negtive_alpha=False,
                is_shortcut=False,
                sc_input_same_clip=True,
                pre_lstm_layer=False,
                op_in_channels=0,
                data_format="NCHW",
                name=""):

        ctx.save_for_backward(input)
        output = imtk_qtp.quantize_feature([
            input, gamma, beta, mean, var, wscale, bias, negtive_alpha,
            conv_res
        ], output_bitwidth, input_bitwidth, weight_bitwidth,
                                           float(clip_min_value),
                                           float(clip_max_value),
                                           target_device, float(feature_var),
                                           float(epsilon), is_fixpoint,
                                           first_layer,
                                           float(clip_min_value_pre),
                                           with_negtive_alpha, is_shortcut,
                                           sc_input_same_clip,
                                           pre_lstm_layer,
                                           op_in_channels,
                                           data_format, name)

        ctx.input_nums = 9
        ctx.output_bitwidth = output_bitwidth
        ctx.clip_min_value = clip_min_value
        ctx.clip_max_value = clip_max_value
        return output

    @staticmethod
    def backward(ctx, grad_output):
        input, = ctx.saved_tensors
        grad_input = imtk_qtp.quantize_feature_backward(
            [grad_output, input], float(ctx.clip_min_value),
            float(ctx.clip_max_value))
        #grads = [None for i in range(1, ctx.input_nums + 13)]
        return grad_input, None, None, None, None, None, None, \
                None, None, None, None, None, None, None, None, \
                None, None, None, None, None, None, None, None, None, None, None, None

class quantize_batchnorm(torch.autograd.Function):
    @staticmethod
    @parse_args('v', 'v', 'v', 'v', 'v', 'v', 'i', 'f', 'f',
                's', 'i', 'f', 'f', 'is', 'is', 'f', 'is', 'is',
                's', 's')
    def symbolic(g,
                 input,
                 gamma,
                 beta,
                 mean,
                 var,
                 negtive_alpha,
                 output_bitwidth,
                 clip_min_value=0.0,
                 clip_max_value=6.0,
                 target_device="Txx",
                 input_bitwidth=32,
                 feature_var=255.0,
                 epsilon=1e-3,
                 is_fixpoint=False,
                 first_layer=False,
                 clip_min_value_pre=0.0,
                 with_negtive_alpha=False,
                 pre_lstm_layer=False,
                 data_format="NCHW",
                 name=""):
        args = [
            input, gamma, beta, mean, var, negtive_alpha
        ]
        kwargs = {
            "input_bitwidth_i": input_bitwidth,
            "output_bitwidth_i": output_bitwidth,
            "clip_min_value_f": clip_min_value,
            "clip_max_value_f": clip_max_value,
            "img_var_f": feature_var,
            "clip_min_pre_f": clip_min_value_pre,
            "epsilon_f": epsilon,
            "target_device_s": target_device,
            "data_format_s": data_format,
            "is_fixpoint_i": is_fixpoint,
            "with_negtive_alpha_i": with_negtive_alpha,
            "pre_lstm_layer_i": pre_lstm_layer,
            "first_layer_i": first_layer,
            "version_i": int(1001),
            "tensor_name_s": name,
        }
        return g.op("QuantizeBatchNormInference", *args, **kwargs)

    @staticmethod
    def forward(ctx,
                input,
                gamma,
                beta,
                mean,
                var,
                negtive_alpha,
                output_bitwidth,
                clip_min_value=0.0,
                clip_max_value=6.0,
                target_device="Txx",
                input_bitwidth=32,
                feature_var=255.0,
                epsilon=1e-3,
                is_fixpoint=False,
                first_layer=False,
                clip_min_value_pre=0.0,
                with_negtive_alpha=False,
                pre_lstm_layer=False,
                data_format="NCHW",
                name=""):

        ctx.save_for_backward(input)
        output = imtk_qtp.quantize_batchnorm([
            input, gamma, beta, mean, var, negtive_alpha
        ], output_bitwidth, input_bitwidth,float(clip_min_value),
                                           float(clip_max_value),
                                           target_device, float(feature_var),
                                           float(epsilon), is_fixpoint,
                                           first_layer,
                                           float(clip_min_value_pre),
                                           with_negtive_alpha,
                                           pre_lstm_layer, data_format, name)

        ctx.input_nums = 6
        ctx.output_bitwidth = output_bitwidth
        ctx.clip_min_value = clip_min_value
        ctx.clip_max_value = clip_max_value
        return output

    @staticmethod
    def backward(ctx, grad_output):
        input, = ctx.saved_tensors
        grad_input = imtk_qtp.quantize_feature_backward(
            [grad_output, input], float(ctx.clip_min_value),
            float(ctx.clip_max_value))
        #grads = [None for i in range(1, ctx.input_nums + 13)]
        return grad_input, None, None, None, None, None, None, \
                None, None, None, None, None, None, None, None, \
                None, None, None, None, None


class NOp(torch.nn.Module):
    __constants__ = ['op_target', 'op_attr', 'target_device']

    def __init__(self, op_target="input", op_attr="{}", target_device="Txx"):
        super(NOp, self).__init__()
        self.op_target = op_target
        self.op_attr = op_attr
        self.target_device = target_device

    def extra_repr(self):
        return 'op_target={op_target}, op_attr={op_attr}, target_device={target_device}'.format(
            **self.__dict__)

    def forward(self, input):
        return n_op.apply(input, self.op_target, self.op_attr,
                          self.target_device)


class QuantizeWeight(torch.nn.Module):
    r"""Applies quantize over the weight of convolution or linear

    * :attr:`w_bit` controls the bit_width of outputs, a int number, less than or equal to 32
    * :attr:`factor` controls the range of the inputs, a float number

    Args:
      w_bit (int):Number of bit_width of the output weights
      factor (float):Number of scaleing of the input weights

    Shape:
      - Input: :math:`(OC, IC, K, K)`
      - Output: :math:`(OC, IC, K, K)` (same shape as input)

    Returns:
      a Tensor of the same dimension and shape as the input, with
      low_bitwidth weight values

    Note: used in convolution or linear layer
    """
    __constants__ = [
        'weight_bitwidth', 'input_bitwidth', 'output_bitwidth', 'factor',
        'need_scale_weight', 'target_device'
    ]

    def __init__(self,
                 weight_bitwidth=32,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 factor=3.0,
                 need_scale_weight=True,
                 target_device="T02"):
        super(QuantizeWeight, self).__init__()

        self.weight_bitwidth = weight_bitwidth
        self.input_bitwidth = input_bitwidth
        self.output_bitwidth = output_bitwidth
        self.factor = factor
        self.target_device = target_device
        self.need_scale_weight = need_scale_weight
        self.name = get_obj_name(self) + "/QuantizeWeight"

    def extra_repr(self):
        return 'weight_bitwidth={weight_bitwidth}, input_bitwidth={input_bitwidth}, output_bitwidth={output_bitwidth}, factor={factor}, need_scale_weight={need_scale_weight}, target_device={target_device}'.format(
            **self.__dict__)

    def forward(self, input):
        input, pre_max = input
        out = quantize_weight.apply(input, pre_max, self.weight_bitwidth,
                                    self.input_bitwidth, self.output_bitwidth,
                                    self.factor, self.need_scale_weight,
                                    self.target_device, self.name)
        return out, pre_max


class QuantizeFeature(torch.nn.Module):
    r"""Applies quantize over the feature map
    * :attr:`output_bitwidth` controls the bit_width of outputs, a int number, less than or equal to 32
    * :attr:`clip_min_value, clip_max_value` controls the range of the inputs, a float number

    Args:
      w_bit (int):Number of bit_width of the output weights
      clip_max_value (float):Number of scaleing of the input weights

    Shape:
      - Input: :math:`(N, H, W, C)`
      - Output: :math:`(N, H, W, C)` (same shape as input)

    Returns:
      a Tensor of the same dimension and shape as the input, with
      low_bitwidth feature values

    Note: used after activation

    Examples::
      >>> m = nn.Conv2d(16, 32, 3, stride=2)
      >>> fa = QuantizeFeature()
      >>> quantize_a = fa(output_bitwidth=4)
      >>> input = torch.randn(2)
      >>> output = quantize_a(F.relu6(m(input)))
    """
    __constants__ = [
        'input_bitwidth', 'output_bitwidth', 'first_layer', 'is_fixpoint',
        'auto_threshold', 'target_device'
    ]

    def __init__(self,
                 op_in_channels,
                 channels,
                 weight_bitwidth=32,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 clip_min_value=0.0,
                 clip_max_value=6.0,
                 epsilon=0.0001,
                 first_layer=False,
                 is_fixpoint=False,
                 auto_threshold=False,
                 is_prelu=False,
                 is_shortcut=False,
                 sc_input_same_clip=True,
                 pre_lstm_layer=False,
                 target_device="T02",
                 data_format="NCHW"):
        super(QuantizeFeature, self).__init__()
        self.op_in_channels = op_in_channels
        self.channels = channels
        self.clip_min_value = clip_min_value
        self.clip_max_value = clip_max_value
        self.weight_bitwidth = weight_bitwidth
        self.input_bitwidth = input_bitwidth
        self.output_bitwidth = output_bitwidth
        self.first_layer = first_layer
        self.epsilon = epsilon
        self.is_fixpoint = is_fixpoint
        self.auto_threshold = auto_threshold
        self.is_prelu = is_prelu
        self.is_shortcut = is_shortcut
        self.sc_input_same_clip = sc_input_same_clip
        self.pre_lstm_layer = pre_lstm_layer
        self.target_device = target_device
        self.data_format = data_format
        self.name = get_obj_name(self) + "/QuantizeFeature"

    def extra_repr(self):
        return 'weight_bitwidth={weight_bitwidth}, input_bitwidth={input_bitwidth}, output_bitwidth={output_bitwidth}, auto_threshold={auto_threshold}, first_layer={first_layer}, is_fixpoint={is_fixpoint}, is_prelu={is_prelu}, target_device={target_device}'.format(
            **self.__dict__)

    def forward(self, input):
        if self.target_device in ["T40", "T02"]:
            is_fixpoint = False if self.training else self.is_fixpoint
        else:
            is_fixpoint = self.is_fixpoint
        if is_fixpoint == False:
            input_tensor = input[0] if isinstance(input, list) else input
            res = quantize_feature.apply(input_tensor, self.output_bitwidth,
                                         self.clip_min_value,
                                         self.clip_max_value,
                                         self.target_device,
                                         self.pre_lstm_layer, self.data_format,
                                         self.name, self.input_bitwidth,
                                         self.weight_bitwidth)
            return res
        gamma = None
        beta = None
        moving_mean = None
        moving_var = None
        w_scale = None
        conv_bias = None
        prelu_alpha_qf = None
        if (len(input) == 5):
            x, gamma, beta, clip_min_value_pre, feature_var = input
            zeros_tensor = torch.zeros_like(gamma)
            ones_tensor = torch.ones_like(gamma)
            conv_res = x
            conv_bias, w_scale, moving_mean, moving_var, prelu_alpha_qf = zeros_tensor, ones_tensor, zeros_tensor, ones_tensor, ones_tensor
        else:
            x, conv_bias, w_scale, gamma, beta, moving_mean, moving_var, prelu_alpha_qf, conv_res, feature_var, clip_min_value_pre = input
        res = quantize_feature_helper.apply(
            x, gamma, beta, moving_mean, moving_var, w_scale, conv_bias,
            prelu_alpha_qf, conv_res, self.output_bitwidth,
            self.clip_min_value, self.clip_max_value, self.target_device,
            self.input_bitwidth, self.weight_bitwidth, feature_var,
            self.epsilon, is_fixpoint, self.first_layer, clip_min_value_pre,
            self.is_prelu, self.is_shortcut, self.sc_input_same_clip,
            self.pre_lstm_layer, self.op_in_channels, self.data_format, self.name)
        return res


class QuantizeBatchNorm(torch.nn.Module):
    r"""Applies quantize over the feature map
    * :attr:`output_bitwidth` controls the bit_width of outputs, a int number, less than or equal to 32
    * :attr:`clip_min_value, clip_max_value` controls the range of the inputs, a float number

    Args:
      w_bit (int):Number of bit_width of the output weights
      clip_max_value (float):Number of scaleing of the input weights

    Shape:
      - Input: :math:`(N, H, W, C)`
      - Output: :math:`(N, H, W, C)` (same shape as input)

    Returns:
      a Tensor of the same dimension and shape as the input, with
      low_bitwidth feature values

    Note: used after activation

    Examples::
      >>> m = nn.Conv2d(16, 32, 3, stride=2)
      >>> fa = QuantizeFeature()
      >>> quantize_a = fa(output_bitwidth=4)
      >>> input = torch.randn(2)
      >>> output = quantize_a(F.relu6(m(input)))
    """
    __constants__ = [
        'input_bitwidth', 'output_bitwidth', 'first_layer', 'is_fixpoint',
        'auto_threshold', 'target_device'
    ]

    def __init__(self,
                 channels,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 clip_min_value=0.0,
                 clip_max_value=6.0,
                 epsilon=0.0001,
                 first_layer=False,
                 is_fixpoint=False,
                 auto_threshold=False,
                 is_prelu=False,
                 pre_lstm_layer=False,
                 target_device="T02",
                 data_format="NCHW"):
        super(QuantizeBatchNorm, self).__init__()
        self.channels = channels
        self.clip_min_value = clip_min_value
        self.clip_max_value = clip_max_value
        self.input_bitwidth = input_bitwidth
        self.output_bitwidth = output_bitwidth
        self.first_layer = first_layer
        self.epsilon = epsilon
        self.is_fixpoint = is_fixpoint
        self.auto_threshold = auto_threshold
        self.is_prelu = is_prelu
        self.pre_lstm_layer = pre_lstm_layer
        self.target_device = target_device
        self.data_format = data_format
        self.name = get_obj_name(self) + "/QuantizeBatchNorm"

    def extra_repr(self):
        return 'input_bitwidth={input_bitwidth}, output_bitwidth={output_bitwidth}, auto_threshold={auto_threshold}, first_layer={first_layer}, is_fixpoint={is_fixpoint}, is_prelu={is_prelu}, target_device={target_device}, clip_min_value={clip_max_value}, clip_min_value={clip_max_value}'.format(
            **self.__dict__)

    def forward(self, input):
        if self.target_device in ["T40", "T02"]:
            is_fixpoint = False if self.training else self.is_fixpoint
        else:
            is_fixpoint = self.is_fixpoint
        if is_fixpoint == False:
            input_tensor = input[0] if isinstance(input, list) else input
            res = quantize_feature.apply(input_tensor, self.output_bitwidth,
                                         self.clip_min_value,
                                         self.clip_max_value,
                                         self.target_device,
                                         self.pre_lstm_layer, self.data_format,
                                         self.name, self.input_bitwidth)
            return res
        x, gamma, beta, moving_mean, moving_var, x0, prelu_alpha_qf, feature_var, clip_min_value_pre = input
        res = quantize_batchnorm.apply(
            x0, gamma, beta, moving_mean, moving_var,
            prelu_alpha_qf, self.output_bitwidth,
            self.clip_min_value, self.clip_max_value, self.target_device,
            self.input_bitwidth, feature_var,
            self.epsilon, is_fixpoint, self.first_layer, clip_min_value_pre,
            self.is_prelu, self.pre_lstm_layer, self.data_format, self.name)
        return res


class Conv2d_Q(nn.Conv2d):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding,
                 dilation, groups, bias, weight_bitwidth, weight_factor,
                 target_device):
        super(Conv2d_Q, self).__init__(in_channels, out_channels, kernel_size,
                                       stride, padding, dilation, groups, None)
        if bias:
            self.bias = Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()
        self.QuantizeWeight = QuantizeWeight(weight_bitwidth=weight_bitwidth,
                                             factor=weight_factor,
                                             target_device=target_device)
        self.out_channels = out_channels

    def forward(self, input):
        input, pre_max = input
        weight_q, pre_max = self.QuantizeWeight([self.weight, pre_max])
        conv_res = F.conv2d(input, weight_q, None, self.stride, self.padding,
                            self.dilation, self.groups)
        if self.bias is not None:
            bias = self.bias
            if len(self.bias.shape) != 4:
                bias = torch.reshape(self.bias, (1, self.out_channels, 1, 1))
            res = conv_res + bias
        else:
            bias = self.bias
            res = conv_res
        return res, bias, pre_max, conv_res


class Linear_Q(nn.Linear):
    def __init__(self, in_features, out_features, bias, weight_bitwidth,
                 weight_factor, target_device):
        super(Linear_Q, self).__init__(in_features, out_features, bias)

        self.QuantizeWeight = QuantizeWeight(weight_bitwidth=weight_bitwidth,
                                             factor=weight_factor,
                                             target_device=target_device)

    def forward(self, input):
        input, pre_max = input
        weight_q, pre_max = self.QuantizeWeight([self.weight, pre_max])
        linear_res = F.linear(input, weight_q)
        if self.bias is not None:
            res = linear_res + self.bias
        else:
            res = linear_res
        return res, self.bias, pre_max, linear_res


class aweight(torch.autograd.Function):
    @staticmethod
    @parse_args('v')
    def symbolic(g, input):
        args = [input]
        return g.op("aweight", *args)

    @staticmethod
    def forward(ctx, input):
        out = input.clone()
        ctx.save_for_backward(input)
        out[out < 0.01] = 0.01
        return out

    @staticmethod
    def backward(ctx, grad_output):
        input, = ctx.saved_tensors
        grad_output[input < 0.01] = 0.
        return grad_output


class AWeight(nn.Module):
    def __init__(self):
        super(AWeight, self).__init__()

    def forward(self, x):
        out = aweight.apply(x)
        return out


class batchNorm2d(nn.Module):
    def __init__(self,
                 in_planes,
                 dim=2,
                 eps=1e-5,
                 momentum=0.1,
                 affine=True,
                 track_running_stats=True):
        super(batchNorm2d, self).__init__()
        self.aweight = AWeight()
        self.batch_norm = nn.BatchNorm2d(in_planes)

    def forward(self, input):
        aweight = self.aweight(self.batch_norm.weight)
        res = F.batch_norm(
            input, self.batch_norm.running_mean, self.batch_norm.running_var,
            aweight, self.batch_norm.bias, self.batch_norm.training
            or not self.batch_norm.track_running_stats)
        return res, aweight, self.batch_norm.bias


class batchNorm1d(nn.Module):
    def __init__(self,
                 in_planes,
                 eps=1e-5,
                 momentum=0.1,
                 affine=True,
                 track_running_stats=True):
        super(batchNorm1d, self).__init__()
        self.aweight = AWeight()
        self.batch_norm = nn.BatchNorm2d(in_planes)

    def forward(self, input):
        aweight = self.aweight(self.batch_norm.weight)
        res = F.batch_norm(
            input, self.batch_norm.running_mean, self.batch_norm.running_var,
            aweight, self.batch_norm.bias, self.batch_norm.training
            or not self.batch_norm.track_running_stats)
        return res, aweight, self.batch_norm.bias


class QuantizeConv2DInference(torch.autograd.Function):
    @staticmethod
    @parse_args('v', 'v', 'v', 'v', 'v', 'v', 'v', 'v', 's')
    def symbolic(g,
                 input,
                 weight,
                 conv_bias,
                 gamma,
                 beta,
                 mean,
                 var,
                 negtive_alpha,
                 param_str):
        args = [input, weight, conv_bias, gamma, beta, mean, var, negtive_alpha]
        kwargs = {
            "param_str_s": param_str,
        }
        return g.op("QuantizeConv2DInference", *args, **kwargs)

    @staticmethod
    def forward(ctx,
                input,
                weight,
                conv_bias,
                gamma,
                beta,
                mean,
                var,
                negtive_alpha,
                param_str):
        res = imtk_qtp.quantize_conv2d_inference([input, weight, conv_bias, gamma, beta, mean, var, negtive_alpha], param_str)
        return res


def get_conv_paramenter(conv_op):
    attr_list = ["in_channels",
                 "out_channels",
                 "kernel_size",
                 "stride",
                 "padding",
                 "dilation",
                 "groups",
                 "padding_mode"]
    transform_attr_list = ["input_channels",
                           "output_channels",
                           "kernel_size",
                           "strides",
                           "pads",
                           "dilations",
                           "groups",
                           "padding_mode"]
    param = {}
    for i in range(len(attr_list)):
        attr = attr_list[i]
        transform_attr = transform_attr_list[i]
        param[transform_attr] = getattr(conv_op, attr)
        if attr == "padding":
            param[transform_attr] = param[transform_attr] + (0,0)
    return param


def quantize_conv2d_inference(x, obj):
    input_min_value = 0.
    input_bitwidth = 32
    feature_var = 255.0
    if obj.first_layer:
        if not isinstance(x, tuple):
            logging.error(
                "you must use ops.Preprocess func; example: ops.Preprocess(inputs, mean = 0.0, var = 255.0)(x)"
            )
            exit()
        input, input_bitwidth, _, feature_var, input_min_value = x
    elif isinstance(x, tuple):
        input, input_bitwidth, input_min_value = x
    else:
        input = x

    if not obj.training and obj.first_layer:
        input = obj.n_op_in(input)

    if obj.is_focus:
        input = obj.Focus(input)
    if obj.target_device == "T02":
        obj.Conv2d.padding = (1, 1)
    elif (obj.padding):
        if not obj.first_layer and obj.target_device == "T40" and input_min_value < 0.:
            input = get_padding(input, obj.Conv2d.kernel_size,
                                obj.Conv2d.stride, -1.)
        else:
            input = get_padding(input, obj.Conv2d.kernel_size,
                                obj.Conv2d.stride)
        obj.Conv2d.padding = (0, 0)

    # get conv param
    conv_param = get_conv_paramenter(obj.Conv2d)

    act_str = None
    activation_fn = obj.activation_fn
    if 'PReLU' in str(activation_fn):
        act_str = "PRelu"
    elif 'LeakyReLU' in str(activation_fn):
        act_str = "LeakyRelu"
    else:
        if obj.flag and obj.QuantizeFeature.clip_min_value == (-obj.QuantizeFeature.clip_max_value):
            act_str = "Linear"
        elif obj.flag and obj.is_hsigmoid:
            act_str = "Hsigmoid"
        else:
            act_str = "ReluX"

    if not obj.training and obj.target_device in ["T40", "T02"]:
        epsilon = obj.QuantizeFeature.epsilon if obj.enable_batch_norm else 0
        param_ditct = {
            "input_bitwidth" : input_bitwidth,
            "output_bitwidth" : obj.output_bitwidth,
            "weight_bitwidth" : obj.weight_bitwidth,
            "clip_min_value" : obj.QuantizeFeature.clip_min_value,
            "clip_max_value" : obj.QuantizeFeature.clip_max_value,
            "weight_factor" : obj.Conv2d.QuantizeWeight.factor,
            "epsilon" : epsilon,
            "is_input" : obj.first_layer,
            "target_device" : obj.target_device,
            "feature_var" : feature_var,
            "input_min_value" : input_min_value,
            "with_negtive_alpha" : obj.is_prelu,
            "is_shortcut" : False,
            "pre_lstm_layer" : obj.QuantizeFeature.pre_lstm_layer,
            "op_in_channels" : obj.QuantizeFeature.op_in_channels,
            "data_format" : obj.QuantizeFeature.data_format,
            "quantize_feature_tensor_name" : obj.QuantizeFeature.name,
            "quantize_weight_tensor_name" : obj.Conv2d.QuantizeWeight.name,
            "quantize_feature_version" : 1001,
            "conv_param" : conv_param,
            "weight_target_device" : obj.Conv2d.QuantizeWeight.target_device,
            "is_output" : obj.last_layer,
            "is_fixpoint" : True,
            "activate_name" : act_str
            }
        ones = torch.ones(obj.out_channels, device=input.device)
        zeros = torch.zeros(obj.out_channels, device=input.device)
        conv_bias = obj.Conv2d.bias if obj.Conv2d.bias is not None else zeros
        gamma = obj.BatchNorm2d.batch_norm.weight if obj.enable_batch_norm else ones
        beta = obj.BatchNorm2d.batch_norm.bias if obj.enable_batch_norm else zeros
        mean = obj.BatchNorm2d.batch_norm.running_mean if obj.enable_batch_norm else zeros
        var = obj.BatchNorm2d.batch_norm.running_var if obj.enable_batch_norm else ones
        negtive_alpha = ones.clone().detach()
        if obj.is_prelu:
            negtive_alpha = obj.negslop.to(input.device) if (
                        obj.negslop is not None) else obj.activation_fn.prelu.weight
        else:
            negtive_alpha = ones
        res = QuantizeConv2DInference.apply(input, obj.Conv2d.weight, conv_bias, gamma, beta, mean, var, negtive_alpha, json.dumps(param_ditct))
        return res
